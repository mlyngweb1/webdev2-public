mytextboxes=document.querySelectorAll('input[type=text]');
for (i=0; i < mytextboxes.length; i++) {
  mytextboxes[i].addEventListener('focus',function() { this. select()},false);
}
