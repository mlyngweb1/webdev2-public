$('.ui.dropdown')
  .dropdown();

function hideAll() {
thecards = document.getElementsByClassName('card');
for (i=0; i < thecards.length; i++) {
  thecards[i].style.display = "none";
  }
}

hideAll();
theuser=document.getElementById("user");
theuser.addEventListener('change', handleChange, false);

function handleChange() {
 hideAll();
 friend=document.getElementById("user").value;

 switch(friend) {

  case "helen":
   document.getElementById("helen").style.display = "block";
   break;
  case "stevie":
   document.getElementById("stevie").style.display = "block";
   break;
  case "christian":
   document.getElementById("christian").style.display = "block";
   break;
  case "matt":
   document.getElementById("matt").style.display = "block";
   break;

  case "jenny":
   document.getElementById("jenny").style.display = "block";
   break;
  case "elliot":
   document.getElementById("elliot").style.display = "block";
   break;

  }

}
