function ProcessMove(playerMove) {
   randomNo = Math.floor(Math.random() * 3 + 1);//Generate a random number between 1 and 3
   switch (randomNo) {
      case 1:
         computerMove = "Rock";
         break;
      case 2:
         computerMove = "Paper";
         break;
      case 3:
         computerMove = "Scissors";
         break;
   }

   compare(playerMove, computerMove); // Call the compare function and pass the computer and player moves

   document.getElementById('CMove').innerHTML = computerMove;
   document.getElementById('PMove').innerHTML = playerMove; // Write Computer Move to the screen// Write Player Move to the screen
   document.getElementById('Msg').innerHTML = result; // Write the result (who won) to the screen

}

function compare(playerMove, computerMove) {
   result="";
   if (playerMove === computerMove) {
      result="You tie!";
   }

   switch (computerMove) {
      case "Rock":
         if (playerMove == "Paper") {
            result="You win!";
         }
         if (playerMove == "Scissors") {
            result="You lose!";
         }
         break;
       case "Paper":
         if (playerMove == "Rock") {
            result="You lose!";
         }
         if (playerMove == "Scissors") {
            result="You win!";
         }
         break;
      case "Scissors":
         if (playerMove == "Rock") {
            result="You win!";
         }
         if (playerMove == "Paper") {
            result="You lose!";
         }
         break;
      }
}


cimg = document.getElementsByTagName('img');
for (i = 0; i < cimg.length; i++) {
   cimg[i].addEventListener('click', handleClick, false);
}

function handleClick() {
	for (i = 0; i < cimg.length; i++) {
		cimg[i].style.borderColor='#F8F8F8';
    }
    this.style.borderColor='#FF4500';
    ProcessMove(this.getAttribute('id'));
}





