$('.ui.dropdown')
  .dropdown();

