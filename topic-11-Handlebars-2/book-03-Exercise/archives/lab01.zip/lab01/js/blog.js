$(document).ready(function() {

const blog =
{
	'title': 'Electroniq Blog',
	'date': 'January 2019',
	'description': "Electroniq is astrophysicist (and retro music enthusiast).",
	'content':
	   '<h2>Welcome to Electroniq</h2><p><em>Electroniq</em> is a new blog about space, distant galaxies and black holes.</p><p>We&#39;ll talk about <a href="https://en.wikipedia.org/wiki/Holographic_principle" target="_blank">the holographic principle</a>, dark matter and the beauty of space in infrared light.</p>',
	'comments':[
	            {'user':'Jane',
	             'date':'Thu Feb 7 2019 15:07:50 GMT+0000 (Greenwich Mean Time)',
	             'comment':'Lovely article.'
	            },
	            {'user':'Pat',
	             'date':'Sat Feb 16 2019 15:07:50 GMT+0000 (Greenwich Mean Time)',
	             'comment':'Great piece of work.'
	            }
	           ]
}

Handlebars.registerHelper('formatDate', function(commentdate) {
  let d = new Date(commentdate);
  let daynum = d.getDate();
  let month = d.getMonth();
  let thisYear = d.getFullYear();

  let months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  let monthname=months[month];

  return  monthname + " " + daynum + ", " + thisYear;
});


});